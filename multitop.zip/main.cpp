#include "fem.h"
#include "mmacontext.h"

int main()
{
	int nelx = 24;
	int nely = 12;
	int nelz = 12;
	double volfrac = 0.4;
	Femproblem fem(nelx, nely, nelz, volfrac, 1);
	vector<int> cons(3 * (nely + 1) * (nelz + 1));
	for (int i = 0; i < cons.size(); ++i)
		cons[i] = i;
	fem.setconstrain(move(cons));
	Eigen::VectorXd force=Eigen::VectorXd::Constant(fem.ndof,0);
	for (int i = 0; i <= nely; ++i)
	{
		force[(nelx * (nely + 1) * (nelz + 1) + i) * 3 + 2] = -1;
	}
	fem.setforce(force);
	mmacontext mma(fem);
	mma.solve_gpu();
	//mma.solve();
	return 0;
}