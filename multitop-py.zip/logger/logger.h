#ifndef _LOGGER_H_
#define _LOGGER_H_

#include<fstream>
#include<string>
#include<vector>

class logger
{
private:
	std::vector<double> list;
	//vector
};

#endif //_LOGGER_H_